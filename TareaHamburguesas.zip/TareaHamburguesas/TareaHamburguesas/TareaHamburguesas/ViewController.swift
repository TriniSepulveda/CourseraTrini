//
//  ViewController.swift
//  TareaHamburguesas
//
//  Created by iMac 27 on 25-04-16.
//  Copyright © 2016 Trinidad Sepulveda. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var LabelPais: UILabel!
    @IBOutlet weak var LabelHamburguesa: UILabel!
    
    let Paises = ColeccionDePaises()
    let Hamburguesas = ColeccionDeHamburguesas()
    let Colores = ColeccionDeColores()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func APretarBoton() {
        
        let NPais = Paises.obtenPais()
        let NHamburguesa = Hamburguesas.obtenHamburguesa()
        let NColor = Colores.regresaColorAleatorio()
        
        LabelPais.text = NPais
        LabelHamburguesa.text = NHamburguesa
        view.backgroundColor = NColor
    }

}

